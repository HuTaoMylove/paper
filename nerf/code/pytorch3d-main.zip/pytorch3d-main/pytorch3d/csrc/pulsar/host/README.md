# Device-specific host compilation units

This folder contains `.cpp` files to create compilation units
for device specific functions. See `../include/README.md` for
more information.
