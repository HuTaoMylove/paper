blending
===========================

.. automodule:: pytorch3d.renderer.blending
    :members:
    :undoc-members:
    :show-inheritance: