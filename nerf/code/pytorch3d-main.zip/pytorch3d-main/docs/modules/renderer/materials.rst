materials
===========================

.. automodule:: pytorch3d.renderer.materials
    :members:
    :undoc-members:
    :show-inheritance: