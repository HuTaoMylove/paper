shader
===========================

.. automodule:: pytorch3d.renderer.mesh.shader
    :members:
    :undoc-members:
    