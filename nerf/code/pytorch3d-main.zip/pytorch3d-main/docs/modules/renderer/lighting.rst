lighting
===========================

.. automodule:: pytorch3d.renderer.lighting
    :members:
    :undoc-members: