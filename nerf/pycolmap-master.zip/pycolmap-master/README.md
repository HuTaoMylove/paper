# pycolmap
Python interface for COLMAP reconstructions, plus some convenient scripts for loading/modifying/converting reconstructions.

This code does not, however, run reconstruction -- it only provides a convenient interface for handling COLMAP's output.
